## --------------------------------------------------------------------------------------------------
    pi.1 <- 0.8
    pi.0 <- 0.2
    
    f.x4.y1 <- dnorm(4, 10, sqrt(36))
    f.x4.y0 <- dnorm(4, 0, sqrt(36))
    
    p.y1 <- (f.x4.y1*pi.1)/(f.x4.y1*pi.1 + f.x4.y0*pi.0)
    p.y1
    


## --------------------------------------------------------------------------------------------------
    library(ISLR)
    data(Auto)
    med.mpg <- median(Auto$mpg)
    med.mpg


## --------------------------------------------------------------------------------------------------
    n <- nrow(Auto)
    n
    mpg01 <- rep(0, n)
    mpg01[Auto$mpg>med.mpg] <- 1
    mpg01 <- mpg01
    summary(as.factor(mpg01))


## --------------------------------------------------------------------------------------------------
    Auto <- data.frame(mpg01, Auto)
    head(Auto)


## --------------------------------------------------------------------------------------------------
    library(ggplot2)
    c <- ggplot(Auto, aes(y=mpg , x=weight, colour=factor(cylinders)))
    c + geom_point()


## --------------------------------------------------------------------------------------------------
    table(Auto$cylinders)


## --------------------------------------------------------------------------------------------------
    p1 <- ggplot(Auto, aes(y=mpg , x=displacement, 
                           colour=factor(cylinders))) + geom_point()
    p1


## --------------------------------------------------------------------------------------------------
    p2 <- ggplot(Auto, aes(y=mpg , x=acceleration, 
                           colour=factor(cylinders))) + geom_point()
    p2


## --------------------------------------------------------------------------------------------------
    p3 <- ggplot(Auto, aes(y=mpg , x=year, 
                           colour=factor(cylinders))) + geom_point()
    p3


## --------------------------------------------------------------------------------------------------
    p4 <- ggplot(Auto, aes(factor(origin), mpg)) + 
      geom_boxplot(aes(fill = factor(origin))) 
    p4 + scale_fill_discrete(labels=c("American", "European", "Japanese"))


## --------------------------------------------------------------------------------------------------
    cor(Auto[, 4:9])


## --------------------------------------------------------------------------------------------------
    set.seed(10)
    sam <- sample(1:n, 100)
    train <- Auto[-sam,]
    test <- Auto[sam, ]
    test.y <- test[,1]
    test.X <- test[,-c(1:2)]


## --------------------------------------------------------------------------------------------------
    cor(train[, c(1,4:9)])[,1]


## --------------------------------------------------------------------------------------------------
    library(MASS)
    lda.fit <- lda(mpg01 ~  displacement + horsepower + weight, data=train)
    lda.fit

    ##
    lda.pred <- predict(lda.fit, test)
    
    lda.class <- lda.pred$class
    table(lda.class, test.y)
    mean(lda.class!= test.y)


## --------------------------------------------------------------------------------------------------
    qda.fit <- qda(mpg01 ~ displacement + horsepower + weight, data=train)
    qda.fit
    
    ##
    qda.pred <- predict(qda.fit, test)
    
    qda.class <- qda.pred$class
    table(qda.class, test.y)
    mean(qda.class!= test.y)


## --------------------------------------------------------------------------------------------------
    glm.fit <- glm(mpg01 ~ cylinders + displacement + horsepower 
                   + weight, data=train, family=binomial)
    summary(glm.fit)

    ##
    glm.probs <- predict (glm.fit, test, type= "response")

    glm.pred <- rep(0, 100)
    glm.pred[glm.probs > 0.5] <- 1
    table(glm.pred, test.y)

    mean(glm.pred!= test.y)


## --------------------------------------------------------------------------------------------------
    library (class)
    set.seed(100)
    
    ##
    train.X <- train[,4:7]
    train.y <- train[,1]
    test.X <- test[,4:7]
    test.y <- test[,1]
    
    ##
    k.use <- 3:25
    test.er <- rep(0, length(k.use))

    for(c in 1:length(k.use)){
    knn.pred <- knn(train.X, test.X, train.y, k=k.use[c])
    test.er[c] <- mean(knn.pred!=test.y)
    }

    ##
    plot(k.use, test.er, type="l", lwd=3)

