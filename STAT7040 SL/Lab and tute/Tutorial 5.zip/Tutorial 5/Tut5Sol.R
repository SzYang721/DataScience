
## ------------------------------------------------------------------------
n <- 1:100000
prob <- 1 - (1-1/n)^(n)

plot(n, prob, type="l", lwd=3, ylim=c(0,1))


## ------------------------------------------------------------------------
n <- 100
S <- 100000
store <- rep(NA, S)
for(s in 1:S){
  store[s] <- sum(sample(1:n, replace = TRUE)==4)>0 
  }

mean(store)


## ------------------------------------------------------------------------
library(ISLR)
data(Default)
attach(Default)
n <- nrow(Default)
n/2


## ------------------------------------------------------------------------
glm.fit <- glm(default ~ income + balance, family=binomial)
summary(glm.fit)


## ------------------------------------------------------------------------
set.seed(1)
train <- sample(1:n, n/2)

glm.fit.train <- glm(default ~ income + balance, family=binomial, 
                     data=Default, subset=train)

p.hat <- predict(glm.fit.train, Default[-train,], type="response")
y.hat <- rep(0, n/2)
y.hat[p.hat>=0.5] <- 1
y <- (Default[-train,]$default=="Yes")*1


## validation approach mse
mean((y-y.hat)^2)


## ------------------------------------------------------------------------
set.seed(1)
err <- NULL

for(s in 1:3){
train <- sample(1:n, n/2)

glm.fit.train <- glm(default ~ income + balance, family=binomial, 
                     data=Default, subset=train)

p.hat <- predict(glm.fit.train, Default[-train,], type="response")
y.hat <- rep(0, n/2)
y.hat[p.hat>=0.5] <- 1
y <- (Default[-train,]$default=="Yes")*1

## validation approach mse
err <- c(err, mean((y-y.hat)^2))
}

err

mean(err)


## ------------------------------------------------------------------------
set.seed(1)
train <- sample(1:n, n/2)

glm.fit.train <- glm(default ~ income + balance + student, family=binomial, 
                     data=Default, subset=train)

summary(glm.fit.train)

##
p.hat <- predict(glm.fit.train, Default[-train,], type="response")
y.hat <- rep(0, n/2)
y.hat[p.hat>=0.5] <- 1
y <- (Default[-train,]$default=="Yes")*1


## validation approach mse
mean((y-y.hat)^2)


## ------------------------------------------------------------------------
glm.fit <- glm(default ~ income + balance, family=binomial)
summary(glm.fit)


## ------------------------------------------------------------------------
boot.fn <- function(Default, Index){
   glm.fit <- glm(default ~ income + balance, family=binomial, 
                  data=Default, subset=Index)
  
  out <- coef(glm.fit)[2:3]
  return(out)
  }

## Let's test the function based on a single bootstrap sample.
## Always check your functions as you write them!  
n <- nrow(Default)
Index <- sample(1:n, replace=TRUE)

boot.fn(Default, Index)


## ------------------------------------------------------------------------
library(boot)
boot(Default, boot.fn, 100)


